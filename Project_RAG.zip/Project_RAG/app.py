import os
import streamlit as st
from langchain_community.vectorstores import FAISS
from langchain_huggingface import HuggingFaceEmbeddings
from langchain.chains.question_answering import load_qa_chain
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import PyPDFLoader
from langchain_community.llms import HuggingFacePipeline
from transformers import pipeline
from dotenv import load_dotenv
load_dotenv()

# ✅ Use a local embedding model
EMBEDDING_MODEL = "all-MiniLM-L6-v2"

# ✅ Load vector store from local FAISS
@st.cache_resource
def load_vectorstore():
    embeddings = HuggingFaceEmbeddings(model_name=EMBEDDING_MODEL)
    vectorstore = FAISS.load_local("faiss_index", embeddings, allow_dangerous_deserialization=True)
    return vectorstore

# ✅ Set up local HuggingFace pipeline
@st.cache_resource
def load_llm():
    pipe = pipeline("text-generation", model="google/flan-t5-base", max_length=512)
    return HuggingFacePipeline(pipeline=pipe)

# ✅ Streamlit UI
st.set_page_config(page_title="📚 PDF Chatbot", layout="centered")
st.title("💬 Chat with your PDF")

user_query = st.text_input("Ask a question about the document:")

if user_query:
    vectorstore = load_vectorstore()
    docs = vectorstore.similarity_search(user_query, k=3)

    llm = load_llm()
    chain = load_qa_chain(llm, chain_type="stuff")

    response = chain.run(input_documents=docs, question=user_query)

    st.markdown("### 📄 Answer")
    st.write(response)
