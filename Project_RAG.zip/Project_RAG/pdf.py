from fpdf import FPDF

pdf = FPDF()
pdf.set_auto_page_break(auto=True, margin=15)
sample_text = (
    "This is sample content for testing a RAG chatbot. "
    "Every page includes repeated sample paragraphs.\n\n"
)

for i in range(1, 201):
    pdf.add_page()
    pdf.set_font("Arial", size=12)
    pdf.multi_cell(0, 10, f"Page {i}\n\n" + sample_text * 5)

pdf.output("long_document.pdf")
print("✅ PDF generated: long_document.pdf")
