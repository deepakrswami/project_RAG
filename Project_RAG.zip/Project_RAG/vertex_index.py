import os
from langchain.vectorstores import FAISS
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import PyPDFLoader
from langchain_community.embeddings import HuggingFaceEmbeddings  # ✅ updated import

# Load and split PDF
def load_pdf_and_split(pdf_path):
    print("📄 Loading and processing PDF...")
    loader = PyPDFLoader(pdf_path)
    documents = loader.load()
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)
    return text_splitter.split_documents(documents)

# Build FAISS index with HuggingFace embeddings
def build_and_save_index(chunks):
    print("🔍 Building embeddings...")
    embeddings = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")  # ✅ Local fast model

    print("🗃️  Creating FAISS index...")
    vectorstore = FAISS.from_documents(chunks, embedding=embeddings)

    print("💾 Saving index to disk...")
    vectorstore.save_local("faiss_index")

# Run the indexing pipeline
pdf_path = "big-book-generative-ai-databricks.pdf"  # or full path if needed
chunks = load_pdf_and_split(pdf_path)
build_and_save_index(chunks)

print("✅ Indexing complete!")
