from langchain.chains import RetrievalQA
from langchain.vectorstores import FAISS
from langchain_community.embeddings import VertexAIEmbeddings
from langchain.llms import VertexAI

def get_qa_chain(index_path="vector_index"):
    embeddings = VertexAIEmbeddings()  # ✅ Now will work

    db = FAISS.load_local(index_path, embeddings, allow_dangerous_deserialization=True)
    llm = VertexAI(model_name="text-bison", temperature=0.2)

    return RetrievalQA.from_chain_type(llm=llm, retriever=db.as_retriever())
